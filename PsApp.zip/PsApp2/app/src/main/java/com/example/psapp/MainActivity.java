package com.example.psapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView text;
    EditText n1,n2;
    Button button,button2,button3,button4;
    TextView textView;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = findViewById(R.id.text);
        n1 = findViewById(R.id.n1);
        n2 = findViewById(R.id.n2);
        button = findViewById(R.id.button);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        textView = findViewById(R.id.textView);
        textView.setText("Arithmetic Operations");
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double div = Double.parseDouble(n1.getText().toString()) / Double.parseDouble(n2.getText().toString());
                text.setText("The Division of Integers :" +div);
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int multi = Integer.parseInt(n1.getText().toString()) * Integer.parseInt(n2.getText().toString());
                text.setText("The Multiplication of Integers :" +multi);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int sub = Integer.parseInt(n1.getText().toString()) - Integer.parseInt(n2.getText().toString());
                text.setText("The Substraction of Integers :" +sub);

            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int sum = Integer.parseInt(n1.getText().toString()) + Integer.parseInt(n2.getText().toString());
                text.setText("The Sum of Integers :" +sum);
            }

        });
    }
}